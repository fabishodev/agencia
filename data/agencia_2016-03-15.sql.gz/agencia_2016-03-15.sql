# ************************************************************
# Sequel Pro SQL dump
# Versi�n 4500
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.42)
# Base de datos: agencia
# Tiempo de Generaci�n: 2016-03-16 01:03:26 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Volcado de tabla cat_categorias
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_categorias`;

CREATE TABLE `cat_categorias` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `estatus` char(1) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `cat_categorias` WRITE;
/*!40000 ALTER TABLE `cat_categorias` DISABLE KEYS */;

INSERT INTO `cat_categorias` (`id`, `nombre`, `descripcion`, `estatus`, `cod_usuario`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,'Extranjero','Viaje al extranjero','1',1,'2016-02-03 18:28:07','2016-02-03 18:53:38'),
	(2,'Concierto','Concierto','1',1,'2016-02-03 18:29:48',NULL),
	(3,'Playa','Viaje redondo a la playa.','1',1,'2016-02-03 22:26:47','2016-03-11 20:44:06'),
	(4,'Tour','Paquete de tipo Tour','1',1,'2016-03-12 02:51:18',NULL);

/*!40000 ALTER TABLE `cat_categorias` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_clientes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_clientes`;

CREATE TABLE `cat_clientes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `correo` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `password` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `nombre` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ape_paterno` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ape_materno` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `domicilio` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `colonia` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ciudad` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `telefono` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `codigo` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `cod_tipo` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

LOCK TABLES `cat_clientes` WRITE;
/*!40000 ALTER TABLE `cat_clientes` DISABLE KEYS */;

INSERT INTO `cat_clientes` (`id`, `usuario`, `correo`, `password`, `nombre`, `ape_paterno`, `ape_materno`, `domicilio`, `colonia`, `ciudad`, `telefono`, `activo`, `codigo`, `cod_tipo`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,NULL,'fabishodev@gmail.com',NULL,'Fabricio','Magaña','Ruiz',NULL,NULL,NULL,'4731081408',NULL,NULL,NULL,'2016-03-15 03:16:52',NULL),
	(2,NULL,'fabishodev@gmail.com',NULL,'Fabricio','Magaña','Ruiz',NULL,NULL,NULL,'4731081408',NULL,NULL,NULL,'2016-03-15 03:27:21',NULL),
	(3,NULL,'fabishodev@gmail.com',NULL,'Fabricio','Magaña','Ruiz',NULL,NULL,NULL,'4731081408',NULL,NULL,NULL,'2016-03-15 04:19:08',NULL);

/*!40000 ALTER TABLE `cat_clientes` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_operadoras
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_operadoras`;

CREATE TABLE `cat_operadoras` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_operadora` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `correo` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `telefono` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `domicilio` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `colonia` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ciudad` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

LOCK TABLES `cat_operadoras` WRITE;
/*!40000 ALTER TABLE `cat_operadoras` DISABLE KEYS */;

INSERT INTO `cat_operadoras` (`id`, `nombre_operadora`, `correo`, `telefono`, `domicilio`, `colonia`, `ciudad`, `activo`, `cod_usuario`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,'Passus Liberi','passus@gmail.com','4611234567','Privada','Los Naranjos','Celaya',1,1,'2016-03-11 20:42:26','2016-03-12 21:25:55'),
	(2,'Curicaheri','curicaheri@localhost.com','4611234567','Privada','Los Naranjos','Celaya',1,1,'2016-03-13 03:23:17',NULL),
	(3,'Luces Mexicanas','luces@localhost.com','4777293358','','','',1,1,'2016-03-14 16:27:48',NULL);

/*!40000 ALTER TABLE `cat_operadoras` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_paquetes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_paquetes`;

CREATE TABLE `cat_paquetes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_categoria` int(11) DEFAULT NULL,
  `cod_operadora` int(11) DEFAULT '1',
  `nombre_paquete` varchar(50) DEFAULT NULL,
  `incluye` text,
  `especificaciones` varchar(300) DEFAULT NULL,
  `lugar` varchar(100) DEFAULT NULL,
  `duracion` varchar(100) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `hora_salida` char(5) DEFAULT NULL,
  `lugar_salida` varchar(50) DEFAULT NULL,
  `fecha_regreso` date DEFAULT NULL,
  `hora_regreso` char(5) DEFAULT NULL,
  `lugar_regreso` varchar(50) DEFAULT NULL,
  `todo_incluido` char(2) DEFAULT 'No',
  `hospedaje_en` varchar(100) DEFAULT NULL,
  `cod_hotel` int(11) DEFAULT NULL,
  `caratula_imagen` varchar(100) DEFAULT NULL,
  `precio` decimal(7,2) DEFAULT '0.00',
  `precio_menor` decimal(7,2) DEFAULT '0.00',
  `precio_adulto_mayor` decimal(7,2) DEFAULT '0.00',
  `denominacion` enum('MX','USD') DEFAULT 'MX',
  `estatus` char(1) DEFAULT NULL,
  `nota` varchar(300) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT '1',
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `cat_paquetes` WRITE;
/*!40000 ALTER TABLE `cat_paquetes` DISABLE KEYS */;

INSERT INTO `cat_paquetes` (`id`, `cod_categoria`, `cod_operadora`, `nombre_paquete`, `incluye`, `especificaciones`, `lugar`, `duracion`, `fecha_salida`, `hora_salida`, `lugar_salida`, `fecha_regreso`, `hora_regreso`, `lugar_regreso`, `todo_incluido`, `hospedaje_en`, `cod_hotel`, `caratula_imagen`, `precio`, `precio_menor`, `precio_adulto_mayor`, `denominacion`, `estatus`, `nota`, `cod_usuario`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,2,1,'Guns And Roses',NULL,'Concierto de Guns And Roses en el Foro Sol de la Ciudad de Mexico','Foro Sol, Ciudad de Mexico','1 dia','2016-04-19','15:00','Parque HIdalgo','2016-04-20','06:00','Afuera del Foro Sol','No','N/A',NULL,'guns-and-roses-pic-oldie.jpg',3500.00,3300.00,3000.00,'MX','1','Incluye bebida de cortesia',1,'2016-02-03 22:21:46','2016-03-15 03:40:08'),
	(2,3,1,'Manzanillo',NULL,'Viaje redondo a Manzanillo, Colima','Manzanillo, Colima','4 dias, 3 noches','2016-02-06','06:00','Central Camionera','2016-02-09','13:00','Afuera del hotel','Si','Tesoro Manzanillo',NULL,'galeria-Juegos-Hotel-Tesoro-Manzanillo-1438278161.jpg',6500.00,5500.00,5000.00,'MX','1','',1,'2016-02-03 22:33:24','2016-03-15 17:37:39'),
	(3,1,1,'Paris Francia All inclusive',NULL,'Viaje redondo a Paris, Francia','Paris, Francia','8 dias, 7 noches.','2016-02-06','07:00','Aeropuerto Mexico DF','2016-02-14','17:00','Aeropuerto Francia','Si','Hotel',NULL,'VIAJE-Paris.jpg',7000.00,0.00,0.00,'USD','1','Aerolinea Aeromexico',1,'2016-02-04 20:35:05','2016-03-11 04:06:14'),
	(5,3,1,'Puerto Vallarta Todo Incluido',NULL,'Viaje redondo a Puerto Vallarta, solo adultos.','Puerto Vallarta, Jal.','4 dias, 3 noches','2016-02-06','02:00','Jardin Principal','2016-02-09','13:00','Hotel Golden Crown','Si','Hotel Golden Crown',NULL,'x1051_2Q4R3vJF_golden_crown_paradise.jpg.pagespeed.ic.MUmda0sVYn.jpg',6500.00,0.00,0.00,'MX','1','Solo adultos.',1,'2016-02-04 22:25:26','2016-03-11 15:56:06');

/*!40000 ALTER TABLE `cat_paquetes` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_tours
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_tours`;

CREATE TABLE `cat_tours` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_categoria` int(11) DEFAULT NULL,
  `cod_operadora` int(11) DEFAULT '1',
  `nombre_tour` varchar(100) DEFAULT NULL,
  `ciudad_lugar` varchar(300) DEFAULT NULL,
  `descripcion` text,
  `resenia_historica` text,
  `incluye` text,
  `duracion` varchar(100) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `hora_salida` char(5) DEFAULT NULL,
  `lugar_salida` varchar(100) DEFAULT NULL,
  `fecha_regreso` date DEFAULT NULL,
  `hora_regreso` char(5) DEFAULT NULL,
  `lugar_regreso` varchar(100) DEFAULT NULL,
  `todo_incluido` char(2) DEFAULT 'No',
  `hospedaje_en` varchar(100) DEFAULT NULL,
  `cod_hotel` int(11) DEFAULT NULL,
  `caratula_imagen` varchar(100) DEFAULT NULL,
  `tarifa_neta` decimal(10,2) DEFAULT NULL,
  `tarifa_impuesto` decimal(10,2) DEFAULT NULL,
  `tarifa_publica` decimal(10,2) DEFAULT NULL,
  `precio` decimal(7,2) DEFAULT '0.00',
  `precio_menor` decimal(7,2) DEFAULT '0.00',
  `precio_adulto_mayor` decimal(7,2) DEFAULT '0.00',
  `politica_compra` text,
  `politica_cancelacion` text,
  `vigencia` date DEFAULT NULL,
  `denominacion` enum('MX','USD') DEFAULT 'MX',
  `estatus` char(1) DEFAULT NULL,
  `nota` text,
  `dias_salidas` varchar(200) DEFAULT NULL,
  `horarios_salidas` varchar(100) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT '1',
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `cat_tours` WRITE;
/*!40000 ALTER TABLE `cat_tours` DISABLE KEYS */;

INSERT INTO `cat_tours` (`id`, `cod_categoria`, `cod_operadora`, `nombre_tour`, `ciudad_lugar`, `descripcion`, `resenia_historica`, `incluye`, `duracion`, `fecha_salida`, `hora_salida`, `lugar_salida`, `fecha_regreso`, `hora_regreso`, `lugar_regreso`, `todo_incluido`, `hospedaje_en`, `cod_hotel`, `caratula_imagen`, `tarifa_neta`, `tarifa_impuesto`, `tarifa_publica`, `precio`, `precio_menor`, `precio_adulto_mayor`, `politica_compra`, `politica_cancelacion`, `vigencia`, `denominacion`, `estatus`, `nota`, `dias_salidas`, `horarios_salidas`, `cod_usuario`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,4,3,'Ruta Tequilera y Arqueologica','Penjamo','imagina un tour donde puedes mezclar dos placeres culturales, descubrir una antigua ciudad prehispanica, y degustar una de las bebidas precolombinas mas famosas del mundo, el tequila. En esta zona podras copnocer el procesoindustrial y artesanal del tequilaal momento que conoces una de las zonas arqueologicas mas completas e impactantes de guanajuato','Adéntrate en el proceso de elaboración del tequila mientras lo degustas en medio de increíbles parajes de agave azul en los alrededores de Pénjamo, Guanajuato. Recorre tres de las tequileras más importantes de la región y descubre todo lo que hay detrás de un caballito de tequila.  \r\nEl denominado Circuito del Tequila inicia en una de las casas tequileras más grandes de México, Tequilera Corralejo. Dentro de la hacienda el tiempo parece detenerse 99 mil horas tal como lo indica la etiqueta de su tequila más emblemático. Como un recordatorio del tiempo que le toma al agave para transformarse en tequila, cientos de relojes adornan la entrada a la cava que poco a poco se ilumina de azul a través de breves espacios que iluminan tu paso por la cava. \r\nLa siguiente parada es la Tequilera Real de Pénjamo en donde te estará esperando una refrescante margarita, bebida elaborada con refresco de toronja, jugo de limón, sal y tequila. El tiempo se pasará volando en compañía del Dr. Arroyo, dueño del lugar quien gusta de transmitir su pasión tequilera. Recorre junto a él parte de sus campos de agave bajo y observa cómo el tono azul se aprecia mejor bajo el claro cielo de Pénjamo. Una vez que te has familiarizado con las plantas, es tiempo de conocer la fábrica donde se encuentran los tanques de destilado para después pasar a la cava. Finaliza tu recorrido con una cata de los diferentes tequilas que esta casa produce y donde la magia artesanal se degusta en cada sorbo. \r\nDirígete a Rancho el Coyote ubicado en las faldas del conocido cerro del Lagarto que resguarda los plantíos de agave azul del tequila Orgullo de Pénjamo, envasado y etiquetado de forma artesanal. Vive la experiencia de la jima o como se le conoce al acto de limpiar la piña o el corazón de la penca de agave. Degusta un caballito de tequila en medio de este impresionante paraje natural rodeado de campos de agave azul enclavados en el corazón de los cerros de Pénjamo.\r\n','guia especializado, trasnportacion redonda, seguro de viajero en el tranporte, acceos a los diferentes recintos, comida prehispanica con cocineras tradicionales','1 Dia',NULL,NULL,'Alameda',NULL,NULL,NULL,'Si','',NULL,'banner-circuitodeltequila.jpg',600.00,696.00,800.00,800.00,600.00,500.00,NULL,NULL,'2016-01-31','MX','1','','Viernes a Domingos','09:00',1,'2016-03-13 21:11:56','2016-03-14 17:30:44'),
	(2,4,1,'Una ruta un destino Mineral de Pozos Pueblo Mágico','Mineral de Pozoz','Disfruta y conoce el pueblo magico de mineral de pozos que te brinda una recorrido de una historia mineral un espectaculo de majestuosas infraestructuras de haciendas y vestigios de la mineros','Los inicios de pozos datan desde la época prehispánica con sus antiguos habitantes, los indios guaxabanos que formaban parte de la gran frontera chichimeca, antes del establecimiento del presidio palmar de Vega, en los años de 1575-1576, unos de los primeros 7 presidios en América. Los cuales se construyeron para la protección de camino real durante la guerra chichimeca que duró casi 50 años. Las minas de este importante lugar existían ya abiertas antes de la conquista, por los indios que radicaban en el territorio minero. \r\n\r\nSu orografía está constituida por dos pequeñas cordilleras separadas por una corta distancia llamadas cerro del Azogue o de Santa Ana y Lobos y la otra Picacho de la Noria. Su riqueza es ser un lugar Mágico y lleno de historia Minera, y reconocido por su imagen colonial donde quedan reflejadas varias de sus leyendas del pueblo Minero. Éste pueblo Mágico es un lugar indispensable en el itinerario de cualquier viajero sofisticado que busca disfrutar de un lugar histórico y culturalmente único para relajarse. Su belleza ha inspirado la creación artística de fotógrafos, pintores y cineastas.  \r\n\r\nVisitar Mineral de pozos te dejara vivir una época Minera he Histórica reflejada en sus paredes de aquella belleza de vestigios arquitectónicos; como ex - Haciendas, compañía Eléctrica, Escuela Modelo, Santa Brijida y su centro que en el refleja el corazón de mineral de pozos.\r\n','1 hospedaje, 2 desayunos, 2 comidas, 1 cena, recorridos centro de mineral de pozos y santa brigida, exposicion cd porfirio diaz, guia especializado, transporte en mineral de pozos','1 dia',NULL,NULL,'Alameda',NULL,NULL,NULL,'No','Hotel Mineral de Pozoz',NULL,'mineral.jpg',1134.00,1350.00,1550.00,1550.00,1550.00,1550.00,NULL,NULL,'2016-01-31','MX','1','','Viernes a Domingos','10:00',1,'2016-03-13 21:20:30','2016-03-14 19:12:16'),
	(3,4,3,'Santuario de Atotonilco y Capilla de Indios','San Miguel de Allende','visitaremos uno de los santurarios mas importantes de guanajuato, la joya del barroco novo hispano, un regalo de mexico al mundo. Las capillas de indios son muestra del proceso de evangelizacion indigena en la epoca colonial','San Miguel de Allende es una ciudad que logra ser pintoresca y cosmopolita al mismo tiempo. Alguna vez fue una importante parada en la ruta de la plata entre Zacatecas y la Ciudad de México. Su centro histórico está lleno de edificios bien conservados que datan de los siglos XVII y XVIII. Con sus estrechas calles empedradas, patios arbolados, finos detalles arquitectónicos y suntuosos interiores, San Miguel de Allende es, sin duda, la ciudad más bonita de México. En 2008, la UNESCO nombró a San Miguel de Allende, y el aledaño Santuario de Jesús de Atotonilco, Patrimonio Mundial de la Humanidad, citando a la arquitectura religiosa y la arquitectura civil del poblado como una muestra de la evolución de las diferentes tendencias y estilos, desde el Barroco hasta el Neogótico de finales del siglo XIX.\r\nCaminar es sin lugar a duda la mejor manera de explorar San Miguel, tambien puedes subir al tranvía que sale desde la oficina de turismo, en el lado norte del Jardín Principal. Después de un recorrido por los principales puntos de interés, te llevará al Mirador, un parador desde donde disfrutarás de una vista panorámica de la ciudad.\r\nEn San Miguel se encuentra una comunidad bastante grande de expatriados, por lo que no es difícil encontrar servicios en inglés, hoteles y restaurantes que satisfacen las necesidades de los norteamericanos, canadienses y europeos que aquí se reúnen. Sin embargo, continúa siendo un poblado muy mexicano, donde los habitantes locales conviven alegremente con los extranjeros que los visitan o que consideran a esta ciudad su hogar.\r\nSan Miguel es un destino preferido para los amantes del arte. Si eres artista principiante,  consumado, o simplemente prefieres admirar las creaciones de los demás, aquí serás feliz. Las inauguraciones de estudios, cursos y talleres constituyen una parte vital de la pujante escena artística. Aquí abundan las galerías, las boutiques y las tiendas que venden una amplia gama de arte y artesanías, por lo que no será difícil encontrar recuerdos que llevar a casa.\r\nA San Miguel de Allende lo rodea un aire de tranquilidad que contradice el hecho de que siempre está sucediendo algo. Ésta es la ciudad perfecta para una estancia prolongada. Puedes tomar clases de arte y sentirte como en casa. Se puede caminar día y noche sin peligro y el clima es agradable todo el año.\r\n','trasnporte redondo desde varias ciudades del estado, guias especializados, guia impresa, hospedaje, desayuno','1 dia',NULL,NULL,'Alameda',NULL,NULL,NULL,'No','',NULL,'san_miguel_nublado.jpg',1700.00,2000.00,2700.00,2700.00,2000.00,1800.00,NULL,NULL,'2016-01-31','MX','1','','Viernes a Domingos','10:00, 12:00, 14:00, 16:00',1,'2016-03-14 16:32:14',NULL);

/*!40000 ALTER TABLE `cat_tours` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_usuarios
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_usuarios`;

CREATE TABLE `cat_usuarios` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `correo` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `password` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `nombre` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ape_paterno` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ape_materno` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `domicilio` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `colonia` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ciudad` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `telefono` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `codigo` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `cod_tipo` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

LOCK TABLES `cat_usuarios` WRITE;
/*!40000 ALTER TABLE `cat_usuarios` DISABLE KEYS */;

INSERT INTO `cat_usuarios` (`id`, `usuario`, `correo`, `password`, `nombre`, `ape_paterno`, `ape_materno`, `domicilio`, `colonia`, `ciudad`, `telefono`, `activo`, `codigo`, `cod_tipo`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,'fmaganaru','fabishodev@gmail.com','12345','Fabricio','Magaña','Ruiz',NULL,NULL,NULL,NULL,1,NULL,0,'2016-02-03 00:00:00',NULL);

/*!40000 ALTER TABLE `cat_usuarios` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla contacto_mensaje
# ------------------------------------------------------------

DROP TABLE IF EXISTS `contacto_mensaje`;

CREATE TABLE `contacto_mensaje` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `asunto` varchar(200) DEFAULT '',
  `mensaje` text,
  `respondido` tinyint(4) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Volcado de tabla galeria_paquetes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `galeria_paquetes`;

CREATE TABLE `galeria_paquetes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_paquete` int(11) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `galeria_paquetes` WRITE;
/*!40000 ALTER TABLE `galeria_paquetes` DISABLE KEYS */;

INSERT INTO `galeria_paquetes` (`id`, `cod_paquete`, `imagen`, `cod_usuario`, `fecha_creado`)
VALUES
	(4,1,'guns-n-roses-2.jpg',1,'2016-02-11 22:12:26'),
	(6,1,'guns-and-roses-pic-oldie.jpg',1,'2016-02-11 22:22:23');

/*!40000 ALTER TABLE `galeria_paquetes` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla galeria_tours
# ------------------------------------------------------------

DROP TABLE IF EXISTS `galeria_tours`;

CREATE TABLE `galeria_tours` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_tour` int(11) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `galeria_tours` WRITE;
/*!40000 ALTER TABLE `galeria_tours` DISABLE KEYS */;

INSERT INTO `galeria_tours` (`id`, `cod_tour`, `imagen`, `cod_usuario`, `fecha_creado`)
VALUES
	(2,1,'barricas_corralejo.jpg',1,'2016-03-14 17:30:31'),
	(3,3,'san miguel romantico.jpg',1,'2016-03-14 19:01:53'),
	(4,3,'san-miguel-de-allende.jpg',1,'2016-03-14 19:02:00'),
	(5,2,'mineral de pozos.jpg',1,'2016-03-14 19:05:48'),
	(6,2,'mineral.jpg',1,'2016-03-14 19:06:01'),
	(7,2,'MineraldePozosGuanajuato01.jpg',1,'2016-03-14 19:06:13');

/*!40000 ALTER TABLE `galeria_tours` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla orden_cabecero
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orden_cabecero`;

CREATE TABLE `orden_cabecero` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_cliente` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `id_respuesta` varchar(20) DEFAULT NULL,
  `autorizacion_respuesta` varchar(10) DEFAULT NULL,
  `status_respuesta` int(11) DEFAULT NULL,
  `fecha_orden` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `orden_cabecero` WRITE;
/*!40000 ALTER TABLE `orden_cabecero` DISABLE KEYS */;

INSERT INTO `orden_cabecero` (`id`, `cod_cliente`, `total`, `id_respuesta`, `autorizacion_respuesta`, `status_respuesta`, `fecha_orden`)
VALUES
	(1,1,1400.00,'trdzv1gmnqpjedeuntdy','801585',0,'2016-03-15 03:16:52'),
	(2,2,4300.00,'trkqk7txpu5dwmykekw0','801585',0,'2016-03-15 03:27:21'),
	(3,3,800.00,NULL,NULL,NULL,'2016-03-15 04:19:08');

/*!40000 ALTER TABLE `orden_cabecero` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla orden_detalle
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orden_detalle`;

CREATE TABLE `orden_detalle` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_cab` int(11) DEFAULT NULL,
  `cod_paquete` int(11) DEFAULT NULL,
  `tipo_orden` varchar(20) DEFAULT NULL,
  `tipo_tarifa` varchar(20) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `fecha_orden` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `orden_detalle` WRITE;
/*!40000 ALTER TABLE `orden_detalle` DISABLE KEYS */;

INSERT INTO `orden_detalle` (`id`, `cod_cab`, `cod_paquete`, `tipo_orden`, `tipo_tarifa`, `cantidad`, `subtotal`, `fecha_orden`)
VALUES
	(1,1,1,'tour','estandar',1,800.00,'2016-03-15 03:16:52'),
	(2,1,1,'tour','menor',1,600.00,'2016-03-15 03:16:52'),
	(3,2,1,'tour','estandar',1,800.00,'2016-03-15 03:27:21'),
	(4,2,1,'paquete','estandar',1,3500.00,'2016-03-15 03:27:21'),
	(5,3,1,'tour','estandar',1,800.00,'2016-03-15 04:19:08');

/*!40000 ALTER TABLE `orden_detalle` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla vw_orden_cabecero
# ------------------------------------------------------------

DROP VIEW IF EXISTS `vw_orden_cabecero`;

CREATE TABLE `vw_orden_cabecero` (
   `id_orden` INT(11) UNSIGNED NOT NULL DEFAULT '0',
   `nombre` VARCHAR(20) NULL DEFAULT NULL,
   `ape_paterno` VARCHAR(20) NULL DEFAULT NULL,
   `ape_materno` VARCHAR(20) NULL DEFAULT NULL,
   `nombre_completo` VARCHAR(62) NULL DEFAULT NULL,
   `correo` VARCHAR(30) NULL DEFAULT NULL,
   `telefono` VARCHAR(10) NULL DEFAULT NULL,
   `total` DECIMAL(10) NULL DEFAULT NULL,
   `id_respuesta` VARCHAR(20) NULL DEFAULT NULL,
   `autorizacion_respuesta` VARCHAR(10) NULL DEFAULT NULL,
   `status_respuesta` BIGINT(11) NOT NULL DEFAULT '0',
   `fecha_orden` DATETIME NULL DEFAULT NULL
) ENGINE=MyISAM;



# Volcado de tabla vw_orden_detalle
# ------------------------------------------------------------

DROP VIEW IF EXISTS `vw_orden_detalle`;

CREATE TABLE `vw_orden_detalle` (
   `id_orden` INT(11) UNSIGNED NOT NULL DEFAULT '0',
   `cod_paquete` INT(11) NULL DEFAULT NULL,
   `subtotal` DECIMAL(10) NULL DEFAULT NULL,
   `tipo_orden` VARCHAR(20) NULL DEFAULT NULL,
   `tipo_tarifa` VARCHAR(20) NULL DEFAULT NULL,
   `nombre` VARCHAR(100) NULL DEFAULT NULL,
   `ciudad_lugar` VARCHAR(300) NULL DEFAULT NULL,
   `cantidad` INT(11) NULL DEFAULT NULL
) ENGINE=MyISAM;





# Replace placeholder table for vw_orden_detalle with correct view syntax
# ------------------------------------------------------------

DROP TABLE `vw_orden_detalle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_orden_detalle` AS (select `a`.`id` AS `id_orden`,`b`.`cod_paquete` AS `cod_paquete`,`b`.`subtotal` AS `subtotal`,`b`.`tipo_orden` AS `tipo_orden`,`b`.`tipo_tarifa` AS `tipo_tarifa`,(case `b`.`tipo_orden` when 'tour' then `d`.`nombre_tour` else `c`.`nombre_paquete` end) AS `nombre`,(case `b`.`tipo_orden` when 'tour' then `d`.`ciudad_lugar` else `c`.`lugar` end) AS `ciudad_lugar`,`b`.`cantidad` AS `cantidad` from ((((`orden_cabecero` `a` left join `orden_detalle` `b` on((`a`.`id` = `b`.`cod_cab`))) left join `cat_paquetes` `c` on((`b`.`cod_paquete` = `c`.`id`))) left join `cat_tours` `d` on((`b`.`cod_paquete` = `d`.`id`))) left join `cat_clientes` `e` on((`a`.`cod_cliente` = `e`.`id`))));


# Replace placeholder table for vw_orden_cabecero with correct view syntax
# ------------------------------------------------------------

DROP TABLE `vw_orden_cabecero`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_orden_cabecero` AS (select `a`.`id` AS `id_orden`,`c`.`nombre` AS `nombre`,`c`.`ape_paterno` AS `ape_paterno`,`c`.`ape_materno` AS `ape_materno`,concat_ws(' ',`c`.`nombre`,`c`.`ape_paterno`,`c`.`ape_materno`) AS `nombre_completo`,`c`.`correo` AS `correo`,`c`.`telefono` AS `telefono`,`a`.`total` AS `total`,`a`.`id_respuesta` AS `id_respuesta`,`a`.`autorizacion_respuesta` AS `autorizacion_respuesta`,ifnull(`a`.`status_respuesta`,1) AS `status_respuesta`,`a`.`fecha_orden` AS `fecha_orden` from (`orden_cabecero` `a` left join `cat_clientes` `c` on((`c`.`id` = `a`.`cod_cliente`))));

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
