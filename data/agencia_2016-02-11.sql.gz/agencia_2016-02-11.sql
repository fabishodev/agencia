# ************************************************************
# Sequel Pro SQL dump
# Versi�n 4499
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.42)
# Base de datos: agencia
# Tiempo de Generaci�n: 2016-02-11 23:15:48 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Volcado de tabla cat_categorias
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_categorias`;

CREATE TABLE `cat_categorias` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `estatus` char(1) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `cat_categorias` WRITE;
/*!40000 ALTER TABLE `cat_categorias` DISABLE KEYS */;

INSERT INTO `cat_categorias` (`id`, `nombre`, `descripcion`, `estatus`, `cod_usuario`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,'Extranjero','Viaje al extranjero','1',1,'2016-02-03 18:28:07','2016-02-03 18:53:38'),
	(2,'Concierto','Concierto','1',1,'2016-02-03 18:29:48',NULL),
	(3,'Playa','Viaje redondo a la playa.','1',1,'2016-02-03 22:26:47',NULL);

/*!40000 ALTER TABLE `cat_categorias` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_paquetes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_paquetes`;

CREATE TABLE `cat_paquetes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_categoria` int(11) DEFAULT NULL,
  `nombre_paquete` varchar(50) DEFAULT NULL,
  `especificaciones` varchar(300) DEFAULT NULL,
  `lugar` varchar(100) DEFAULT NULL,
  `duracion` varchar(100) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `hora_salida` char(5) DEFAULT NULL,
  `lugar_salida` varchar(50) DEFAULT NULL,
  `fecha_regreso` date DEFAULT NULL,
  `hora_regreso` char(5) DEFAULT NULL,
  `lugar_regreso` varchar(50) DEFAULT NULL,
  `todo_incluido` char(2) DEFAULT 'No',
  `hospedaje_en` varchar(100) DEFAULT NULL,
  `cod_hotel` int(11) DEFAULT NULL,
  `caratula_imagen` varchar(100) DEFAULT NULL,
  `precio` decimal(7,2) DEFAULT '0.00',
  `denominacion` enum('MX','USD') DEFAULT 'MX',
  `estatus` char(1) DEFAULT NULL,
  `nota` varchar(300) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT '1',
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `cat_paquetes` WRITE;
/*!40000 ALTER TABLE `cat_paquetes` DISABLE KEYS */;

INSERT INTO `cat_paquetes` (`id`, `cod_categoria`, `nombre_paquete`, `especificaciones`, `lugar`, `duracion`, `fecha_salida`, `hora_salida`, `lugar_salida`, `fecha_regreso`, `hora_regreso`, `lugar_regreso`, `todo_incluido`, `hospedaje_en`, `cod_hotel`, `caratula_imagen`, `precio`, `denominacion`, `estatus`, `nota`, `cod_usuario`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,2,'Guns And Roses','Concierto de Guns And Roses en el Foro Sol de la Ciudad de Mexico','Foro Sol, Ciudad de Mexico','1 dia','2016-04-19','15:00','Parque HIdalgo','2016-04-20','06:00','Afuera del Foro Sol','No','N/A',NULL,'guns-and-roses-pic-oldie.jpg',3500.00,'MX','1','Incluye bebida de cortesia',1,'2016-02-03 22:21:46','2016-02-05 00:11:05'),
	(2,3,'Manzanillo','Viaje redondo a Manzanillo, Colima','Manzanillo, Colima','4 dias, 3 noches','2016-02-06','06:00','Central Camionera','2016-02-09','13:00','Afuera del hotel','Si','Tesoro Manzanillo',NULL,'galeria-Juegos-Hotel-Tesoro-Manzanillo-1438278161.jpg',6500.00,'MX','1','',1,'2016-02-03 22:33:24','2016-02-05 00:13:27'),
	(3,1,'Paris, Francia All inclusive','Viaje redondo a Paris, Francia','Paris, Francia','8 dias, 7 noches.','2016-02-06','07:00','Aeropuerto Mexico DF','2016-02-14','17:00','Aeropuerto Francia','Si','Hotel',NULL,'VIAJE-Paris.jpg',7000.00,'USD','1','Aerolinea Aeromexico',1,'2016-02-04 20:35:05','2016-02-05 02:11:29'),
	(5,3,'Puerto Vallarta Todo Incluido','Viaje redondo a Puerto Vallarta, solo adultos.','Puerto Vallarta, Jal.','4 dias, 3 noches','2016-02-06','02:00','Jardin Principal','2016-02-09','13:00','Hotel Golden Crown','Si','Hotel Golden Crown',NULL,'x1051_2Q4R3vJF_golden_crown_paradise.jpg.pagespeed.ic.MUmda0sVYn.jpg',6500.00,'MX','1','Solo adultos.',1,'2016-02-04 22:25:26','2016-02-05 02:11:19');

/*!40000 ALTER TABLE `cat_paquetes` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla cat_usuarios
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cat_usuarios`;

CREATE TABLE `cat_usuarios` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `correo` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `password` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `nombre` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ape_paterno` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ape_materno` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `domicilio` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `colonia` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `ciudad` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `telefono` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `codigo` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `cod_tipo` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  `fecha_actualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

LOCK TABLES `cat_usuarios` WRITE;
/*!40000 ALTER TABLE `cat_usuarios` DISABLE KEYS */;

INSERT INTO `cat_usuarios` (`id`, `usuario`, `correo`, `password`, `nombre`, `ape_paterno`, `ape_materno`, `domicilio`, `colonia`, `ciudad`, `telefono`, `activo`, `codigo`, `cod_tipo`, `fecha_creado`, `fecha_actualizado`)
VALUES
	(1,'fmaganaru','fabishodev@gmail.com','12345','Fabricio','Magaña','Ruiz',NULL,NULL,NULL,NULL,1,NULL,0,'2016-02-03 00:00:00',NULL);

/*!40000 ALTER TABLE `cat_usuarios` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla galeria_paquetes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `galeria_paquetes`;

CREATE TABLE `galeria_paquetes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cod_paquete` int(11) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `cod_usuario` int(11) DEFAULT NULL,
  `fecha_creado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `galeria_paquetes` WRITE;
/*!40000 ALTER TABLE `galeria_paquetes` DISABLE KEYS */;

INSERT INTO `galeria_paquetes` (`id`, `cod_paquete`, `imagen`, `cod_usuario`, `fecha_creado`)
VALUES
	(4,1,'guns-n-roses-2.jpg',1,'2016-02-11 22:12:26'),
	(6,1,'guns-and-roses-pic-oldie.jpg',1,'2016-02-11 22:22:23');

/*!40000 ALTER TABLE `galeria_paquetes` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
